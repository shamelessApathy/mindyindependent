<?php
/**
 * Name: Default
 * Description: Default template for MarketPress invoice
 */
//only for information