<div class="wrap coursepress_wrapper coursepress-upgrade">
	<h1><?php esc_html_e( 'Upgrade', 'cp' ); ?></h1>
<?php CoursePress_View_Admin_Upgrade::render_page(); ?>
</div>