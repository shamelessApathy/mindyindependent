<?php
/**
 * Premium specific module.
 *
 * @package CoursePressPro
 */

/**
 * Initialize the Premium extras.
 */
class CoursePressPro_Core {

	/**
	 * Hook up the Premium options!
	 *
	 * @since  2.0.0
	 */
	public static function init() {
		// Nothing here yet...
	}
}