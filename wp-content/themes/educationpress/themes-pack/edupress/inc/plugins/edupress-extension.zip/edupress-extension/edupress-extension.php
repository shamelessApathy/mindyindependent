<?php
/**
 * @wordpress-plugin
 * Plugin Name:       EduPress Extension
 * Plugin URI:        http://ThemeCycle.com/
 * Description:       Custom post types for EduPress Theme
 * Version:           1.0.0
 * Author:            Ahmed
 * Author URI:        http://themeforest.net/user/ThemeCycle
 * Text Domain:       edupress-extension
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}


add_action( 'init', 'edupress_extension_load_textdomain' );
/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 */
function edupress_extension_load_textdomain() {
  load_plugin_textdomain( 'edupress-extension', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
}

$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';
global $pagenow;
	
if( !function_exists( 'edupress_is_a' ) )
{
	function edupress_is_a( $theme_mode ) {
		
		$demo_selected	= isset($_REQUEST['demo-select']) ? $_REQUEST['demo-select'] : false;
		if( $demo_selected !== false )
		{
			return $demo_selected == $theme_mode;
		}
		
		global $edupress_options;
		if( empty($edupress_options)) {
			$opt  = get_option( 'edupress_options' );
			
			if($opt)
				return $opt['edupress_theme_mode'] == $theme_mode;	
			else
				return $theme_mode == 'uni';	
		}
		return $edupress_options['edupress_theme_mode'] == $theme_mode;
	}
}		
if(is_admin() && $pagenow == 'themes.php' && !empty( $_GET['page'] )
			 && $_GET['page']== 'educationpress_demo_installer' && 'demo-data' == $action ) 
{
	require_once( plugin_dir_path( __FILE__ ).'edupress-uni-extension.php');
	require_once( plugin_dir_path( __FILE__ ).'edupress-kid-extension.php');
}

if( edupress_is_a( 'uni' ) )
{
	require_once( plugin_dir_path( __FILE__ ).'edupress-uni-extension.php');
}
elseif( edupress_is_a( 'kid' ) )
{
	require_once( plugin_dir_path( __FILE__ ).'edupress-kid-extension.php');
}
?>