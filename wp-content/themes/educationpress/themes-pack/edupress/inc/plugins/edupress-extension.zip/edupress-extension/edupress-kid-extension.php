<?php
/**
 *
 * @link              http://themeforest.net/user/ThemeCycle
 * @since             1.0.0
 * @package          EduPress
 *
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}




// Register Custom Post Type
function edupress_kid_extension_custom_post_type() {

	$labels = array(
		'name'                  => _x( 'Classes', 'Post Type General Name', 'edupress-extension' ),
		'singular_name'         => _x( 'Class', 'Post Type Singular Name', 'edupress-extension' ),
		'menu_name'             => __( 'Classes', 'edupress-extension' ),
		'name_admin_bar'        => __( 'Class', 'edupress-extension' ),
		'archives'              => __( 'Class Archives', 'edupress-extension' ),
		'parent_item_colon'     => __( 'Parent class:', 'edupress-extension' ),
		'all_items'             => __( 'All Classes', 'edupress-extension' ),
		'add_new_item'          => __( 'Add New Class', 'edupress-extension' ),
		'add_new'               => __( 'Add New Class', 'edupress-extension' ),
		'new_item'              => __( 'New Class', 'edupress-extension' ),
		'edit_item'             => __( 'Edit Class', 'edupress-extension' ),
		'update_item'           => __( 'Update Class', 'edupress-extension' ),
		'view_item'             => __( 'View Class', 'edupress-extension' ),
		'search_items'          => __( 'Search Class', 'edupress-extension' ),
		'not_found'             => __( 'Not found', 'edupress-extension' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'edupress-extension' ),
		'featured_image'        => __( 'Featured Image', 'edupress-extension' ),
		'set_featured_image'    => __( 'Set featured image', 'edupress-extension' ),
		'remove_featured_image' => __( 'Remove featured image', 'edupress-extension' ),
		'use_featured_image'    => __( 'Use as featured image', 'edupress-extension' ),
		'insert_into_item'      => __( 'Insert into class', 'edupress-extension' ),
		'uploaded_to_this_item' => __( 'Uploaded to this class', 'edupress-extension' ),
		'items_list'            => __( 'Items list', 'edupress-extension' ),
		'items_list_navigation' => __( 'Items list navigation', 'edupress-extension' ),
		'filter_items_list'     => __( 'Filter items list', 'edupress-extension' ),
	);
	$args = array(
		'label'                 => __( 'Class', 'edupress-extension' ),
		'description'           => __( 'Kindergarten Classes For EduPress Kindergarten theme', 'edupress-extension' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'excerpt',  'thumbnail','custom-fields' ),
		//'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'           => 'dashicons-welcome-learn-more',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'class', $args );	
	   
	
	$labels = array(
		'name'                       => _x( 'Category', 'Taxonomy General Name', 'themecycle-exten' ),
		'singular_name'              => _x( 'Category', 'Taxonomy Singular Name', 'themecycle-exten' ),
		'menu_name'                  => __( 'Categories', 'themecycle-exten' ),
		'all_items'                  => __( 'All Categories', 'themecycle-exten' ),
		'parent_item'                => __( 'Parent Category', 'themecycle-exten' ),
		'parent_item_colon'          => __( 'Parent Category:', 'themecycle-exten' ),
		'new_item_name'              => __( 'New Category', 'themecycle-exten' ),
		'add_new_item'               => __( 'Add New Category', 'themecycle-exten' ),
		'edit_item'                  => __( 'Edit Category', 'themecycle-exten' ),
		'update_item'                => __( 'Update Category', 'themecycle-exten' ),
		'view_item'                  => __( 'View Category', 'themecycle-exten' ),
		'separate_items_with_commas' => __( 'Separate Categories with commas', 'themecycle-exten' ),
		'add_or_remove_items'        => __( 'Add or remove Categories', 'themecycle-exten' ),
		'choose_from_most_used'      => __( 'Choose from the most used', 'themecycle-exten' ),
		'popular_items'              => __( 'Popular Categories', 'themecycle-exten' ),
		'search_items'               => __( 'Search Categories', 'themecycle-exten' ),
		'not_found'                  => __( 'Not Found', 'themecycle-exten' ),
	);

	$rewrite = array(
		'slug'                       => __( 'class-category', 'themecycle-exten' ),
		'with_front'                 => true,
		'hierarchical'               => true,
	);
	$args = array(
            'labels'                     => $labels,
            'hierarchical'               => true,
            'public'                     => true,
            'show_ui'                    => true,
            'show_admin_column'          => true,
            'show_in_nav_menus'          => true,
            'show_tagcloud'              => true,
            'rewrite'                    => $rewrite,
        );

     register_taxonomy( 'class-category', array( 'class' ), $args );

}
add_action( 'init', 'edupress_kid_extension_custom_post_type', 0 );




