<?php
add_action( 'import_start', 'edupress_university_import_start' );
function edupress_university_import_start() {
	$role = get_role( 'administrator' );
		$role->add_cap( 'read' );
		
		update_user_meta( 1, 'job_title', "Head In Nichola's Sports Academy" );
		update_user_meta( 1, 'mob_num', '9999919293' );
		update_user_meta( 1, 'facebook_url', 'http://facebook.com' );
		update_user_meta( 1, 'twitter_url', 'http://twitter.com' );
		update_user_meta( 1, 'google_plus_url', 'http://google.com' );
		update_user_meta(1, 'linkedin_url', 'http://linkedin.com' );
		update_user_meta( 1, 'pinterest_url', 'http://pinterest.com' );
		update_user_meta(1, 'instagram_url', 'http://instagram.com' );
		update_user_meta( 1, 'youtube_url', 'http://youtube.com' );
	
		
		
		
		$userdata2 = array(
		'user_login'  =>  'themecycledemo',
		'user_email' =>  '	themecycledemo@gmail.com',
		'user_pass'   =>  '12345',  // When creating an user, `user_pass` is expected.
		'user_nicename' => 'emmawilson',
		'display_name' => 'Emma Wilson',
		'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet nulla sed neque congue pharetra sed sed leo. Pellentesque elementum porttitor libero hendrerit porta. Aenean vitae odio semper, iaculis nibh non, hendrerit augue. Nam non tincidunt justo, eu fermentum nulla',
		'first_name' => 'Theme Cycle',
		'last_name' => 'Demo',
		//'role' => 'Author',
		);
		update_user_meta( $user_id2, 'job_title', 'Coach' );
		update_user_meta( $user_id2, 'mob_num', '3-541-754-3010' );
		update_user_meta( $user_id2, 'facebook_url', 'http://facebook.com' );
		update_user_meta( $user_id2, 'twitter_url', 'http://twitter.com' );
		update_user_meta( $user_id2, 'google_plus_url', 'http://google.com' );
		update_user_meta( $user_id2, 'linkedin_url', 'http://linkedin.com' );
		update_user_meta( $user_id2, 'pinterest_url', 'http://pinterest.com' );
		update_user_meta( $user_id2, 'instagram_url', 'http://instagram.com' );
		update_user_meta( $user_id2, 'youtube_url', 'http://youtube.com' );
		
		$user_id2 = wp_insert_user( $userdata2 ) ;
		
		$userdata3 = array(
		'user_login'  =>  'emmawilson',
		'user_email' =>  'emmawilson008@gmail.com',
		'user_pass'   =>  '12345',  // When creating an user, `user_pass` is expected.
		'user_nicename' => 'emmawilson',
		'display_name' => 'Emma Wilson',
		'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet nulla sed neque congue pharetra sed sed leo. Pellentesque elementum porttitor libero hendrerit porta. Aenean vitae odio semper, iaculis nibh non, hendrerit augue. Nam non tincidunt justo, eu fermentum nulla',
		'first_name' => 'Emma',
		'last_name' => 'Wilson',
		//'role' => 'Author',
		);
		$user_id3 = wp_insert_user( $userdata3 ) ;
		update_user_meta( $user_id3, 'job_title', 'Coach' );
		update_user_meta( $user_id3, 'mob_num', '3-541-754-3010' );
		update_user_meta( $user_id3, 'facebook_url', 'http://facebook.com' );
		update_user_meta( $user_id3, 'twitter_url', 'http://twitter.com' );
		update_user_meta( $user_id3, 'google_plus_url', 'http://google.com' );
		update_user_meta( $user_id3, 'linkedin_url', 'http://linkedin.com' );
		update_user_meta( $user_id3, 'pinterest_url', 'http://pinterest.com' );
		update_user_meta( $user_id3, 'instagram_url', 'http://instagram.com' );
		update_user_meta( $user_id3, 'youtube_url', 'http://youtube.com' );
		
		$userdata4 = array(
		'user_login'  =>  'stevedown',
		'user_email' =>  'stevedown00@gmail.com',
		'user_pass'   =>  '12345',  // When creating an user, `user_pass` is expected.
		'user_nicename' => 'stevedown',
		'display_name' => 'Steve Down',
		'first_name' => 'Steve',
		'last_name' => 'Down',
		'nickname' => 'stevedown',
		'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet nulla sed neque congue pharetra sed sed leo. Pellentesque elementum porttitor libero hendrerit porta. Aenean vitae odio semper, iaculis nibh non, hendrerit augue. Nam non tincidunt justo, eu fermentum nulla',
		'rich_editing' => 'true',
		'comment_shortcuts' => 'false',
		'admin_color' => 'fresh',
		'use_ssl' => '0',
		'show_admin_bar_front' => 'true',
		'dismissed_wp_pointers' => '',
		//'role' => 'Author',
		);
		$user_id4 = wp_insert_user( $userdata4 ) ;
		
		update_user_meta( $user_id4, 'job_title', 'Professor' );
		update_user_meta( $user_id4, 'mob_num', '3-541-754-3010' );
		update_user_meta( $user_id4, 'facebook_url', 'http://facebook.com' );
		update_user_meta( $user_id4, 'twitter_url', 'http://twitter.com' );
		update_user_meta( $user_id4, 'google_plus_url', 'http://google.com' );
		update_user_meta( $user_id4, 'linkedin_url', 'http://linkedin.com' );
		update_user_meta( $user_id4, 'pinterest_url', 'http://pinterest.com' );
		update_user_meta( $user_id4, 'instagram_url', 'http://instagram.com' );
		update_user_meta( $user_id4, 'youtube_url', 'http://youtube.com' );
	

		
		$userdata5 = array(
		'user_login'  =>  'Joneslee',
		'user_email' =>  'Joneslee500@gmail.com',
		'user_pass'   =>  '12345',  // When creating an user, `user_pass` is expected.
		'user_nicename' => 'Joneslee',
		'display_name' => 'Jones Lee',
		'first_name' => 'Jones',
		'last_name' => 'Lee',
		'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet nulla sed neque congue pharetra sed sed leo. Pellentesque elementum porttitor libero hendrerit porta. Aenean vitae odio semper, iaculis nibh non, hendrerit augue. Nam non tincidunt justo, eu fermentum nulla',
		'nickname' => 'Joneslee',
		//'role' => 'Author',
		);
		
		$user_id5 = wp_insert_user( $userdata5 ) ;
		update_user_meta( $user_id5, 'job_title', 'Lab assitant' );
		update_user_meta( $user_id5, 'mob_num', '1-541-754-3010' );
		update_user_meta( $user_id5, 'facebook_url', 'http://facebook.com' );
		update_user_meta( $user_id5, 'twitter_url', 'http://twitter.com' );
		update_user_meta( $user_id5, 'google_plus_url', 'http://google.com' );
		update_user_meta( $user_id5, 'linkedin_url', 'http://linkedin.com' );
		update_user_meta( $user_id5, 'pinterest_url', 'http://pinterest.com' );
		update_user_meta( $user_id5, 'instagram_url', 'http://instagram.com' );
		update_user_meta( $user_id5, 'youtube_url', 'http://youtube.com' );
		
		
		
		$userdata6 = array(
		'user_login'  =>  'cherrywalker',
		'user_email' =>  'cherrywalker00@gmail.com',
		'user_pass'   =>  '12345',  // When creating an user, `user_pass` is expected.
		'user_nicename' => 'cherrywalker',
		'display_name' => 'Cherry Walker',
		'first_name' => 'Cherry',
		'last_name' => 'Walker',
		'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet nulla sed neque congue pharetra sed sed leo. Pellentesque elementum porttitor libero hendrerit porta. Aenean vitae odio semper, iaculis nibh non, hendrerit augue. Nam non tincidunt justo, eu fermentum nulla',
		'nickname' => 'cherrywalker',
		//'role' => 'Author',
		);
		
		$user_id6 = wp_insert_user( $userdata6 ) ;
		update_user_meta( $user_id6, 'job_title', 'Professor' );
		update_user_meta( $user_id6, 'mob_num', '8-541-754-3010' );
		update_user_meta( $user_id6, 'facebook_url', 'http://facebook.com' );
		update_user_meta( $user_id6, 'twitter_url', 'http://twitter.com' );
		update_user_meta( $user_id6, 'google_plus_url', 'http://google.com' );
		update_user_meta( $user_id6, 'linkedin_url', 'http://linkedin.com' );
		update_user_meta( $user_id6, 'pinterest_url', 'http://pinterest.com' );
		update_user_meta( $user_id6, 'instagram_url', 'http://instagram.com' );
		update_user_meta( $user_id6, 'youtube_url', 'http://youtube.com' );
	
		//---------------------------------------------------------		
		$userdata7 = array(
		'user_login'  =>  'jamesbond',
		'user_email' =>  'jamesbond100008@gmail.com',
		'user_pass'   =>  '12345',  // When creating an user, `user_pass` is expected.
		'user_nicename' => 'jamesbond',
		'display_name' => 'James Bond',
		'first_name' => 'James',
		'last_name' => 'Bond',
		'nickname' => 'jamesbond',
		'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet nulla sed neque congue pharetra sed sed leo. Pellentesque elementum porttitor libero hendrerit porta. Aenean vitae odio semper, iaculis nibh non, hendrerit augue. Nam non tincidunt justo, eu fermentum nulla',
		//'role' => 'Author',
		);
		
		$user_id7 = wp_insert_user( $userdata7 ) ;
		
		
		update_user_meta( $user_id7, 'job_title', 'Head of Department' );
		update_user_meta( $user_id7, 'mob_num', '9999919293' );
		update_user_meta( $user_id7, 'facebook_url', 'http://facebook.com' );
		update_user_meta( $user_id7, 'twitter_url', 'http://twitter.com' );
		update_user_meta( $user_id7, 'google_plus_url', 'http://google.com' );
		update_user_meta( $user_id7, 'linkedin_url', 'http://linkedin.com' );
		update_user_meta( $user_id7, 'pinterest_url', 'http://pinterest.com' );
		update_user_meta( $user_id7, 'instagram_url', 'http://instagram.com' );
		update_user_meta( $user_id7, 'youtube_url', 'http://youtube.com' );

		
		//---------------------------------------------------------
		$userdata8 = array(
		'user_login'  =>  'josefermola',
		'user_email' =>  'josefermola95@gmail.com',
		'user_pass'   =>  '12345',  // When creating an user, `user_pass` is expected.
		'user_nicename' => 'josefermola',
		'display_name' => 'Josef Ermola',
		'first_name' => 'Josef',
		'last_name' => 'Ermola',
		'nickname' => 'josefermola',
		'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet nulla sed neque congue pharetra sed sed leo. Pellentesque elementum porttitor libero hendrerit porta. Aenean vitae odio semper, iaculis nibh non, hendrerit augue. Nam non tincidunt justo, eu fermentum nulla',
		//'role' => 'Author',
		);
		
		$user_id8 = wp_insert_user( $userdata8 ) ;
		
		update_user_meta( $user_id8, 'job_title', 'Lecturer' );
		update_user_meta( $user_id8, 'mob_num', '9-541-754-3010' );
		update_user_meta( $user_id8, 'facebook_url', 'http://facebook.com' );
		update_user_meta( $user_id8, 'twitter_url', 'http://twitter.com' );
		update_user_meta( $user_id8, 'google_plus_url', 'http://google.com' );
		update_user_meta( $user_id8, 'linkedin_url', 'http://linkedin.com' );
		update_user_meta( $user_id8, 'pinterest_url', 'http://pinterest.com' );
		update_user_meta( $user_id8, 'instagram_url', 'http://instagram.com' );
		update_user_meta( $user_id8, 'youtube_url', 'http://youtube.com' );
		
		//---------------------------------------------------------	
		$userdata9 = array(
		'user_login'  =>  'terrencetillman878',
		'user_email' =>  'terrencetillman878@gmail.com',
		'user_pass'   =>  '12345',  // When creating an user, `user_pass` is expected.
		'user_nicename' => 'terrencetillman878',
		'display_name' => 'Terrence Tillman',
		'first_name' => 'Terrence',
		'last_name' => 'Tillman',
		'nickname' => 'terrencetillman878',
		'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet nulla sed neque congue pharetra sed sed leo. Pellentesque elementum porttitor libero hendrerit porta. Aenean vitae odio semper, iaculis nibh non, hendrerit augue. Nam non tincidunt justo, eu fermentum nulla',
		//'role' => 'Author',
		);
		
		$user_id9 = wp_insert_user( $userdata9 ) ;
		
		
		update_user_meta( $user_id9, 'job_title', 'Assistant Professor' );
		update_user_meta( $user_id9, 'mob_num', '9999919293' );
		update_user_meta( $user_id9, 'facebook_url', 'http://facebook.com' );
		update_user_meta( $user_id9, 'twitter_url', 'http://twitter.com' );
		update_user_meta( $user_id9, 'google_plus_url', 'http://google.com' );
		update_user_meta( $user_id9, 'linkedin_url', 'http://linkedin.com' );
		update_user_meta( $user_id9, 'pinterest_url', 'http://pinterest.com' );
		update_user_meta( $user_id9, 'instagram_url', 'http://instagram.com' );
		update_user_meta( $user_id9, 'youtube_url', 'http://youtube.com' );

		
}
function edupress_university_set_course_user() {
	
	return true;
}

function edupress_university_radium_import_end() {
	
		$page = get_page_by_title( 'Home Page 1' );
		if ( isset( $page->ID ) ) {
					update_option( 'page_on_front', $page->ID );
					update_option( 'show_on_front', 'page' );
					
					
					$news_cat = get_term_by('name', 'News', 'category');
					$ann_cat = get_term_by('name', 'Announcements', 'category');
					
					$panels_data = get_post_meta( $page->ID, 'panels_data', true );
					$panels_data['widgets'][2]['post_cat'] = (int) $news_cat->term_id;
					$panels_data['widgets'][5]['post_cat'] = (int) $ann_cat->news_cat;
					
					$home_menu   = get_term_by('name', 'Home Menu', 'nav_menu');
					$panels_data['widgets'][6]['nav_menu'] = (int) $home_menu->term_id;
			
					
					update_post_meta( $page->ID, 'panels_data', $panels_data );
					
				}
		
		$page = get_page_by_title( 'Home Page 2' );
		if ( isset( $page->ID ) ) {
					
					
					$news_cat = get_term_by('name', 'News', 'category');
					$ann_cat = get_term_by('name', 'Announcements', 'category');
					
					$panels_data = get_post_meta( $page->ID, 'panels_data', true );
					$panels_data['widgets'][2]['post_cat'] = (int) $ann_cat->term_id;
					$panels_data['widgets'][4]['post_cat'] = (int) $news_cat->news_cat;
					
					$home_menu   = get_term_by('name', 'Home Menu', 'nav_menu');
					$panels_data['widgets'][5]['nav_menu'] = (int) $home_menu->term_id;
					update_post_meta( $page->ID, 'panels_data', $panels_data );
	
	
				}
				
		
		
		$args_form = array("post_type" => "mc4wp-form", "s" => 'Sign up Form');
		$form_post = get_posts( $args_form );
		if( intval($form_post[0]->ID) > 0)
		{
			$short_code = '[mc4wp_form id="'.intval($form_post[0]->ID).'"]';
			$options = get_option( 'edupress_options', $default = false );
			if($options)
			{
				$options['edupress_newsletter_shortcode'] = $short_code;
				update_option( 'edupress_options', $options );
			}


			
		}
		
		$widget_nav_menu = get_option('widget_nav_menu', false);
		if($widget_nav_menu) 
		{
			$home_menu   = get_term_by('name', 'Home Menu', 'nav_menu');
			if( intval( $home_menu->term_id ) > 0)
			{
				$widget_nav_menu[2]['nav_menu'] = intval( $home_menu->term_id );
				update_option('widget_nav_menu', $widget_nav_menu);
			}
		}
		
				
		/*User Set Section Start */
		edupress_university_set_course_user();
		/*User Set Section End */
				
		$page = get_page_by_title( 'Blog' );
		if ( isset( $page->ID ) ) {
			update_option( 'page_for_posts', $page->ID );
		}
		
	flush_rewrite_rules();	
	update_option( 'edupress_extension_loader_need_rewrite', 1);	
}
add_action( 'radium_import_end', 'edupress_university_radium_import_end', 999 );  
//add_action( 'init', 'edupress_university_radium_import_end' );  

//add_action('init', function() {
	add_action( 'radium_theme_import_widget_settings' , 'edupress_extent_set_widget_menu');	
	function edupress_extent_set_widget_menu($wid_obj)
	{
			
			
		if(isset( $wid_obj->nav_menu) ) {
			
			$footer_menu   = get_term_by('name', 'Footer Menu', 'nav_menu');
			$wid_obj->nav_menu = intval( $footer_menu->term_id );
		
		}
		return $wid_obj;
	}
//});