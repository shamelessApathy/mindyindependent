<?php
/**
 *
 * @link              http://themeforest.net/user/ThemeCycle
 * @since             1.0
 * @package          EduPress
 *
 * @wordpress-plugin
 * Plugin Name:       EduPress Extensions Loader
 * Plugin URI:        http://ThemeCycle.com/
 * Description:       EduPress Extensions loader plugin for import demo data of EduPress
 * Version:           1.0.2
 * Author:            Ahmed
 * Author URI:        http://themeforest.net/user/ThemeCycle
 * Text Domain:       edupress
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}
define( 'EDUPRESS_EXT_PATH', plugin_dir_path( __FILE__ ) );


/*
register_activation_hook( __FILE__, 'edupress_ecommerce_extension_loader_activation');
function edupress_ecommerce_extension_loader_activation(){
	add_option( 'edupress_ecommerce_extension_loader_need_rewrite', 0);	
}
*/

add_action( 'init',  'edupress_extension_loader_init' );
function edupress_extension_loader_init() {
	
	$edupress_ecommerce_extension_loader_need_rewrite = get_option( 'edupress_extension_loader_need_rewrite', '0');	
	if( $edupress_ecommerce_extension_loader_need_rewrite != '0') {
			flush_rewrite_rules();
			update_option( 'edupress_extension_loader_need_rewrite', 0);
	}
}





/*
ini_set('max_execution_time', 1800);
ini_set('memory_limit', '256M');
*/
require_once( plugin_dir_path( __FILE__).'init.php' );


add_action( 'plugins_loaded', 'edupress_exten_load_textdomain' );
/**
 * Load plugin textdomain.
 *
 *
 */
function edupress_exten_load_textdomain() {
  load_plugin_textdomain( 'exten-load', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' ); 
}

/*
add_action( 'init', function(){
	$page_id = edupress_ecommerce_get_last_post_id_by_title('All Courses');
	
	echo $page_id;
	die;
	});
	
	
function edupress_ecommerce_get_last_post_id_by_title($page_title, $output = OBJECT ) {
    global $wpdb;
	//Query all columns so as not to use get_post()
    $results = $wpdb->get_results( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_title = %s AND post_type = %s AND post_status = 'publish' ORDER BY post_date DESC", $page_title, 'page' ) );

    if ( $results ){
        $output = array();
        foreach ( $results as $post ){
            $output = $post->ID;
        }
        return $output;
    }
    return 0;
}


*/