<?php
add_action( 'import_start', 'edupress_ecommerce_import_start' );
function edupress_ecommerce_import_start() {
	$role = get_role( 'administrator' );
		$role->add_cap( 'read' );
		
		update_user_meta( 1, 'job_title', "Head In Nichola's Sports Academy" );
		update_user_meta( 1, 'mob_num', '9999919293' );
		update_user_meta( 1, 'facebook_url', 'http://facebook.com' );
		update_user_meta( 1, 'twitter_url', 'http://twitter.com' );
		update_user_meta( 1, 'google_plus_url', 'http://google.com' );
		update_user_meta(1, 'linkedin_url', 'http://linkedin.com' );
		update_user_meta( 1, 'pinterest_url', 'http://pinterest.com' );
		update_user_meta(1, 'instagram_url', 'http://instagram.com' );
		update_user_meta( 1, 'youtube_url', 'http://youtube.com' );
			
		$userdata2 = array(
		'user_login'  =>  'themecycledemo',
		'user_email' =>  '	themecycledemo@gmail.com',
		'user_pass'   =>  '12345',  // When creating an user, `user_pass` is expected.
		'user_nicename' => 'emmawilson',
		'display_name' => 'Emma Wilson',
		'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet nulla sed neque congue pharetra sed sed leo. Pellentesque elementum porttitor libero hendrerit porta. Aenean vitae odio semper, iaculis nibh non, hendrerit augue. Nam non tincidunt justo, eu fermentum nulla',
		'first_name' => 'Theme Cycle',
		'last_name' => 'Demo',
		'role' => 'Author',
		);
		
		$user_id = wp_insert_user( $userdata2 ) ;
		
		$userdata3 = array(
		'user_login'  =>  'emmawilson',
		'user_email' =>  'emmawilson008@gmail.com',
		'user_pass'   =>  '12345',  // When creating an user, `user_pass` is expected.
		'user_nicename' => 'emmawilson',
		'display_name' => 'Emma Wilson',
		'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet nulla sed neque congue pharetra sed sed leo. Pellentesque elementum porttitor libero hendrerit porta. Aenean vitae odio semper, iaculis nibh non, hendrerit augue. Nam non tincidunt justo, eu fermentum nulla',
		'first_name' => 'Emma',
		'last_name' => 'Wilson',
		'role' => 'Author',
		);
		$user_id3 = wp_insert_user( $userdata3 ) ;
		update_user_meta( $user_id3, 'job_title', 'Coach' );
		update_user_meta( $user_id3, 'mob_num', ' 3-541-754-3010' );
		update_user_meta( $user_id3, 'facebook_url', 'http://facebook.com' );
		update_user_meta( $user_id3, 'twitter_url', 'http://twitter.com' );
		update_user_meta( $user_id3, 'google_plus_url', 'http://google.com' );
		update_user_meta( $user_id3, 'linkedin_url', 'http://linkedin.com' );
		update_user_meta( $user_id3, 'pinterest_url', 'http://pinterest.com' );
		update_user_meta( $user_id3, 'instagram_url', 'http://instagram.com' );
		update_user_meta( $user_id3, 'youtube_url', 'http://youtube.com' );
		
		
		$userdata4 = array(
		'user_login'  =>  'stevedown',
		'user_email' =>  'stevedown00@gmail.com',
		'user_pass'   =>  '12345',  // When creating an user, `user_pass` is expected.
		'user_nicename' => 'stevedown',
		'display_name' => 'Steve Down',
		'first_name' => 'Steve',
		'last_name' => 'Down',
		'nickname' => 'stevedown',
		'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet nulla sed neque congue pharetra sed sed leo. Pellentesque elementum porttitor libero hendrerit porta. Aenean vitae odio semper, iaculis nibh non, hendrerit augue. Nam non tincidunt justo, eu fermentum nulla',
		'rich_editing' => 'true',
		'comment_shortcuts' => 'false',
		'admin_color' => 'fresh',
		'use_ssl' => '0',
		'show_admin_bar_front' => 'true',
		'dismissed_wp_pointers' => '',
		'role' => 'Author',
		);
		$user_id4 = wp_insert_user( $userdata4 ) ;
		
		update_user_meta( $user_id4, 'job_title', 'Android, IOS & Web Developer' );
		update_user_meta( $user_id4, 'mob_num', '9999919293' );
		update_user_meta( $user_id4, 'facebook_url', 'http://facebook.com' );
		update_user_meta( $user_id4, 'twitter_url', 'http://twitter.com' );
		update_user_meta( $user_id4, 'google_plus_url', 'http://google.com' );
		update_user_meta( $user_id4, 'linkedin_url', 'http://linkedin.com' );
		update_user_meta( $user_id4, 'pinterest_url', 'http://pinterest.com' );
		update_user_meta( $user_id4, 'instagram_url', 'http://instagram.com' );
		update_user_meta( $user_id4, 'youtube_url', 'http://youtube.com' );
	
	

		$role = new WP_User( $user_id4 );
		
		/*
		$role->add_cap( 'can_edit_posts' );
		$role->add_cap( 'read' );
		$role->add_cap( 'upload_files' );

		foreach ( $instructor_capabilities as $cap ) {
			$role->add_cap( $cap );
		}
		*/
		
		$userdata5 = array(
		'user_login'  =>  'Joneslee',
		'user_email' =>  'Joneslee500@gmail.com',
		'user_pass'   =>  '12345',  // When creating an user, `user_pass` is expected.
		'user_nicename' => 'Joneslee',
		'display_name' => 'Jones Lee',
		'first_name' => 'Jones',
		'last_name' => 'Lee',
		'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet nulla sed neque congue pharetra sed sed leo. Pellentesque elementum porttitor libero hendrerit porta. Aenean vitae odio semper, iaculis nibh non, hendrerit augue. Nam non tincidunt justo, eu fermentum nulla',
		'nickname' => 'Joneslee',
		'role' => 'Author',
		);
		
		$user_id5 = wp_insert_user( $userdata5 ) ;
		
		
		update_user_meta( $user_id5, 'job_title', 'Lab assitant' );
		update_user_meta( $user_id5, 'mob_num', '9-541-754-3010' );
		update_user_meta( $user_id5, 'facebook_url', 'http://facebook.com' );
		update_user_meta( $user_id5, 'twitter_url', 'http://twitter.com' );
		update_user_meta( $user_id5, 'google_plus_url', 'http://google.com' );
		update_user_meta( $user_id5, 'linkedin_url', 'http://linkedin.com' );
		update_user_meta( $user_id5, 'pinterest_url', 'http://pinterest.com' );
		update_user_meta( $user_id5, 'instagram_url', 'http://instagram.com' );
		update_user_meta( $user_id5, 'youtube_url', 'http://youtube.com' );
	
		
	
		
		
		$userdata6 = array(
		'user_login'  =>  'cherrywalker',
		'user_email' =>  'cherrywalker00@gmail.com',
		'user_pass'   =>  '12345',  // When creating an user, `user_pass` is expected.
		'user_nicename' => 'cherrywalker',
		'display_name' => 'Cherry Walker',
		'first_name' => 'Cherry',
		'last_name' => 'Walker',
		'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet nulla sed neque congue pharetra sed sed leo. Pellentesque elementum porttitor libero hendrerit porta. Aenean vitae odio semper, iaculis nibh non, hendrerit augue. Nam non tincidunt justo, eu fermentum nulla',
		'nickname' => 'cherrywalker',
		'role' => 'Author',
		);
		
		$user_id6 = wp_insert_user( $userdata6 ) ;
		
		update_user_meta( $user_id6, 'job_title', 'Professor' );
		update_user_meta( $user_id6, 'mob_num', '2-541-754-3010' );
		update_user_meta( $user_id6, 'facebook_url', 'http://facebook.com' );
		update_user_meta( $user_id6, 'twitter_url', 'http://twitter.com' );
		update_user_meta( $user_id6, 'google_plus_url', 'http://google.com' );
		update_user_meta( $user_id6, 'linkedin_url', 'http://linkedin.com' );
		update_user_meta( $user_id6, 'pinterest_url', 'http://pinterest.com' );
		update_user_meta( $user_id6, 'instagram_url', 'http://instagram.com' );
		update_user_meta( $user_id6, 'youtube_url', 'http://youtube.com' );
		
	
		
		$userdata7 = array(
		'user_login'  =>  'jamesbond',
		'user_email' =>  'jamesbond100008@gmail.com',
		'user_pass'   =>  '12345',  // When creating an user, `user_pass` is expected.
		'user_nicename' => 'jamesbond',
		'display_name' => 'James Bond',
		'first_name' => 'James',
		'last_name' => 'Bond',
		'nickname' => 'jamesbond',
		'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet nulla sed neque congue pharetra sed sed leo. Pellentesque elementum porttitor libero hendrerit porta. Aenean vitae odio semper, iaculis nibh non, hendrerit augue. Nam non tincidunt justo, eu fermentum nulla',
		'role' => 'Author',
		);
		
		$user_id7 = wp_insert_user( $userdata7 ) ;
		
		
		update_user_meta( $user_id7, 'job_title', 'UX Designer' );
		update_user_meta( $user_id7, 'mob_num', '9999919293' );
		update_user_meta( $user_id7, 'facebook_url', 'http://facebook.com' );
		update_user_meta( $user_id7, 'twitter_url', 'http://twitter.com' );
		update_user_meta( $user_id7, 'google_plus_url', 'http://google.com' );
		update_user_meta( $user_id7, 'linkedin_url', 'http://linkedin.com' );
		update_user_meta( $user_id7, 'pinterest_url', 'http://pinterest.com' );
		update_user_meta( $user_id7, 'instagram_url', 'http://instagram.com' );
		update_user_meta( $user_id7, 'youtube_url', 'http://youtube.com' );

		
	
		$userdata8 = array(
		'user_login'  =>  'josefermola',
		'user_email' =>  'josefermola95@gmail.com',
		'user_pass'   =>  '12345',  // When creating an user, `user_pass` is expected.
		'user_nicename' => 'josefermola',
		'display_name' => 'Josef Ermola',
		'first_name' => 'Josef',
		'last_name' => 'Ermola',
		'nickname' => 'josefermola',
		'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet nulla sed neque congue pharetra sed sed leo. Pellentesque elementum porttitor libero hendrerit porta. Aenean vitae odio semper, iaculis nibh non, hendrerit augue. Nam non tincidunt justo, eu fermentum nulla',
		'role' => 'Author',
		);
		
		$user_id8 = wp_insert_user( $userdata8 ) ;
		update_user_meta( $user_id8, 'job_title', 'Lecturer' );
		update_user_meta( $user_id8, 'mob_num', '9999919293' );
		update_user_meta( $user_id8, 'facebook_url', 'http://facebook.com' );
		update_user_meta( $user_id8, 'twitter_url', 'http://twitter.com' );
		update_user_meta( $user_id8, 'google_plus_url', 'http://google.com' );
		update_user_meta( $user_id8, 'linkedin_url', 'http://linkedin.com' );
		update_user_meta( $user_id8, 'pinterest_url', 'http://pinterest.com' );
		update_user_meta( $user_id8, 'instagram_url', 'http://instagram.com' );
		update_user_meta( $user_id8, 'youtube_url', 'http://youtube.com' );
		
			
		$userdata9 = array(
		'user_login'  =>  'terrencetillman878',
		'user_email' =>  'terrencetillman878@gmail.com',
		'user_pass'   =>  '12345',  // When creating an user, `user_pass` is expected.
		'user_nicename' => 'terrencetillman878',
		'display_name' => 'Terrence Tillman',
		'first_name' => 'Terrence',
		'last_name' => 'Tillman',
		'nickname' => 'terrencetillman878',
		'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet nulla sed neque congue pharetra sed sed leo. Pellentesque elementum porttitor libero hendrerit porta. Aenean vitae odio semper, iaculis nibh non, hendrerit augue. Nam non tincidunt justo, eu fermentum nulla',
		'role' => 'Author',
		);
		
		$user_id9 = wp_insert_user( $userdata9 ) ;
		
		
		update_user_meta( $user_id9, 'job_title', 'Web Apps Developer' );
		update_user_meta( $user_id9, 'mob_num', '9999919293' );
		update_user_meta( $user_id9, 'facebook_url', 'http://facebook.com' );
		update_user_meta( $user_id9, 'twitter_url', 'http://twitter.com' );
		update_user_meta( $user_id9, 'google_plus_url', 'http://google.com' );
		update_user_meta( $user_id9, 'linkedin_url', 'http://linkedin.com' );
		update_user_meta( $user_id9, 'pinterest_url', 'http://pinterest.com' );
		update_user_meta( $user_id9, 'instagram_url', 'http://instagram.com' );
		update_user_meta( $user_id9, 'youtube_url', 'http://youtube.com' );

		
}
function edupress_ecommerce_set_course_user() {
	$user_array = array();
	
	$user = get_user_by('login','emmawilson');
	$user_array[] = $user->ID;
	
	$user = get_user_by('login','stevedown');
	$user_array[] = $user->ID;
	
	$user = get_user_by('login','Joneslee');
	$user_array[] = $user->ID;
	
	$user = get_user_by('login','cherrywalker');
	$user_array[] = $user->ID;
	
	$user = get_user_by('login','jamesbond');
	$user_array[] = $user->ID;
	
	$user = get_user_by('login','josefermola');
	$user_array[] = $user->ID;
	
	$args = array(
		'post_type' => 'product',
		'post_status' => 'publish',
	);
	
	$the_query = new WP_Query( $args );
	
	
	// The Loop
	if ( $the_query->have_posts() ) {
		while ( $the_query->have_posts() ) {
			$the_query->the_post();
			
			
			$temp = array_rand( $user_array, 1);
			
			$my_post = array(
     			 'ID'           => get_the_ID(),
				 'post_author'    => $user_array[$temp], 
			  
		  );
			wp_update_post($my_post);
			
			
		}
		/* Restore original Post Data */
		wp_reset_postdata();
	} 

	
	
	
	
}


function edupress_ecommerce_get_last_post_id_by_title($page_title, $output = OBJECT ) {
    global $wpdb;
	//Query all columns so as not to use get_post()
    $results = $wpdb->get_results( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_title = %s AND post_type = %s AND post_status = 'publish' ORDER BY post_date DESC", $page_title, 'page' ) );

    if ( $results ){
        $output = array();
        foreach ( $results as $post ){
            $output = $post->ID;
        }
        return $output;
    }
    return 0;
}
function edupress_ecommerce_radium_import_end() {
	if( edupress_is_a( 'ecom' ) ) :
		$page = get_page_by_title( 'Home Page 1' );
		if ( isset( $page->ID ) ) {
					update_option( 'page_on_front', $page->ID );
					update_option( 'show_on_front', 'page' );
					$cat1=get_term_by('name', 'Sports', 'product_cat');
					$cat2=get_term_by('name', 'Food Recipe', 'product_cat');
					$cat3=get_term_by('name', 'Web Development', 'product_cat');
					$cat4=get_term_by('name', 'Music', 'product_cat');
					$cat5=get_term_by('name', 'Frontend', 'product_cat');
					$cat6=get_term_by('name', 'Multi Language', 'product_cat');
					$course_cat[]=  (int) $cat1->term_id;
					$course_cat[]=  (int) $cat2->term_id;
					$course_cat[]=  (int) $cat3->term_id;
					$course_cat[]=  (int) $cat4->term_id;
					$course_cat[]=  (int) $cat5->term_id;
					$course_cat[]=  (int) $cat6->term_id;
					
					update_term_meta( (int) $cat1->term_id, 'ec_cat_short_text', 'Lorem Ipsum is simply dummy text of the printing and dolor site amet dolor.' );
					update_term_meta( (int) $cat2->term_id, 'ec_cat_short_text', 'Maecenas cursus mauris libero, a imperdiet enim pellentesque id.' );
					update_term_meta( (int) $cat3->term_id, 'ec_cat_short_text', 'Maecenas cursus mauris libero, a imperdiet enim pellentesque id. Aliquam erat volutpat Lorem Ipsum is simply dummy.' );
					update_term_meta( (int) $cat4->term_id, 'ec_cat_short_text', 'Make a type specimen book.' );
					update_term_meta( (int) $cat5->term_id, 'ec_cat_short_text', 'Make a type specimen book.' );
					update_term_meta( (int) $cat6->term_id, 'ec_cat_short_text', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' );
					
					$panels_data = get_post_meta( $page->ID, 'panels_data', true );
					$panels_data['widgets'][3]['course_cat']=$course_cat;
					update_post_meta( $page->ID, 'panels_data', $panels_data );
			
				}
		
		$page = get_page_by_title( 'Home Page 3' );
		if ( isset( $page->ID ) ) {
					$cat1=get_term_by('name', 'Sports', 'product_cat');
					$cat2=get_term_by('name', 'Food Recipe', 'product_cat');
					$cat3=get_term_by('name', 'Web Development', 'product_cat');
					$cat4=get_term_by('name', 'Music', 'product_cat');
					$cat5=get_term_by('name', 'Frontend', 'product_cat');
					$cat6=get_term_by('name', 'Multi Language', 'product_cat');
					$course_cat1[]=  (int) $cat1->term_id;
					$course_cat1[]=  (int) $cat2->term_id;
					$course_cat1[]=  (int) $cat3->term_id;
					$course_cat1[]=  (int) $cat6->term_id;
					$course_cat1[]=  (int) $cat4->term_id;
					$course_cat1[]=  (int) $cat5->term_id;
					
					$panels_data = get_post_meta( $page->ID, 'panels_data', true );
					$panels_data['widgets'][0]['course_cat']=$course_cat1;
					update_post_meta( $page->ID, 'panels_data', $panels_data );
				}
								
		/*User Set Section Start */
		edupress_ecommerce_set_course_user();
		/*User Set Section End */
				
		$page = get_page_by_title( 'Blog' );
		if ( isset( $page->ID ) ) {
			update_option( 'page_for_posts', $page->ID );
		}
		
		$page_id = edupress_ecommerce_get_last_post_id_by_title('All Courses');
		if ( $page_id > 0) {
			update_option( 'woocommerce_shop_page_id', $page_id );
		}
	endif;
	flush_rewrite_rules();	
	update_option( 'edupress_extension_loader_need_rewrite', 1);	
}
add_action( 'radium_import_end', 'edupress_ecommerce_radium_import_end' );  